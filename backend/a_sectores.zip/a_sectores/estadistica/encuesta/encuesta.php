<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Documento sin t&iacute;tulo</title>

<style type="text/css">
<!--
.Estilo3 {
	font-family: "Trebuchet MS";
	color: #FFFFFF;
}
-->
</style>
<link href="../../../menus.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.Estilo58 {font-size: 12px}
.Estilo15 {font-family: "Trebuchet MS"}
-->
</style>
</head>

<body>
<table width="154"  border="0">
  <tr bgcolor="#990033"> </tr>
  <tr>
    <td bgcolor="#666666"><div align="center" class="Estilo3">ENCUESTAS</div></td>
  </tr>
</table>
<div id="menuv">
		<ul>
			<ul>
			 			  
<li><a href="carga_datos.php" target = "central1" class="Estilo7 Estilo58" >1. Cargar Encuesta </a></li>
<!-- <li><a href="resultado_encuesta1.php" target = "central1" class="Estilo7 Estilo58" >2. Resultado Encuesta</a></li> -->
 

<!-- <li><a href="direccion/pacientes_atendidos_entrega.php" target = "central1" class="Estilo7 Estilo58" >7. Cantidad de Entregas</a></li> -->
<!-- <li><a href="direccion/grafico1.php" target = "central1" class="Estilo7 Estilo58" >5. Prueba</a></li>
<li><a href="direccion/grafico2.php" target = "central1" class="Estilo7 Estilo58" >5. Prueba</a></li>
<li><a href="direccion/diag/ex.php" target = "central1" class="Estilo7 Estilo58" >5. Prueba</a></li> -->

<!-- <li><a href="../ver_asiento_gtin.php" target = "central1" class="Estilo7 Estilo58" >5. Prueba</a></li> -->
<!-- <li><a href="existencia/consulta.php" target = "central1" class="Estilo7 Estilo58" >5. Existencia</a></li>  -->

</ul>
		</ul>
</div>
  
  <?PHP 
  $mes = date("m");
  $anio = date("y");


  ?>
   <form action="buscar_encuesta.php" method="post" target = "central1">
<table width="152"  border="0">
  <tr bgcolor="#990033"> </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td bgcolor="#666666"><div align="center" class="Estilo3">ENCUESTAS</div></td>
  </tr>
  <tr>
    <td align="center" class="Estilo79 Estilo58 Estilo15" scope="row">PERIODO
      <input name = "mes" type = "text" id="mes" size = "2" value = "<?php echo $mes;?>"></td>
  </tr>
  <tr>
    <td align="center" class="Estilo79 Estilo58 Estilo15" scope="row">A&Ntilde;O
      20
      <input name = "anio" type = "text" id="anio" size = "2" value = "<?php echo $anio;?>" ></td>
  </tr>
  <tr>
    <td align="center" class="Estilo79 Estilo58 Estilo15" scope="row"><label>
      <select name="tipo_encuesta[]" id="tipo_encuesta">
          <option value="RESULTADO">RESULTADO</option>
          <option value="LISTADO">LISTADO</option>
        </select>
    </label></td>
  </tr>
  <tr>
    <td align="center" class="Estilo7" scope="row"><input name="Submit2" type="submit" value="BUSCAR" /></td>
  </tr>
</table>
   </form> 
</body>
</html>
