<?php
 $sql = "SELECT *  FROM `tr_ventas_encabezado` WHERE `fecha` between '$desde' and '$hasta' and cod_movimiento != 6  and cod_movimiento != 3 and forma_pago = '$departamento'   group by documento ";
$result = $db->Execute($sql);
$recetas_pro = $result->RecordCount(); 

$sql = "SELECT *  FROM `tr_ventas_encabezado` WHERE `fecha` between '$desde' and '$hasta' and  cod_movimiento = 3  and forma_pago = '$departamento' group by documento ";
$result = $db->Execute($sql);
$recetas_nc_pro = $result->RecordCount(); 

$recetas_pro = $recetas_pro - $recetas_nc_pro;


 $sql = "SELECT count(nro_factura) as total, sum(neto) as neto  FROM `tr_ventas_encabezado` WHERE `fecha` between '$desde' and '$hasta' and cod_movimiento != 6  and cod_movimiento != 3 and forma_pago = '$departamento' ";
$result = $db->Execute($sql);
$facturas=$result->fields["total"];
$neto_pro=$result->fields["neto"];

 $sql = "SELECT count(nro_factura) as total, sum(neto) as neto  FROM `tr_ventas_encabezado` WHERE `fecha` between '$desde' and '$hasta' and cod_movimiento = 3 and forma_pago = '$departamento' ";
$result = $db->Execute($sql);
$facturas_nc=$result->fields["total"];
$neto_nc_pro=$result->fields["neto"];


$neto = $neto_pro - $neto_nc_pro;


 
?>