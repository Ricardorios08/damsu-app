<?php


$sql11 = "SELECT * FROM `tr_ventas_encabezado` where fecha between '$desde' and '$hasta' and cod_movimiento = 2 order by nro_factura ";
$result = $db->Execute($sql11);




if (!$result) die("fallo".$db->ErrorMsg());

 while (!$result->EOF) {


$nro_factura=$result->fields["nro_factura"];
$tipo_fact=$result->fields["tipo_fact"];
$nro_factura=$result->fields["nro_factura"];
$fecha=$result->fields["fecha"];
$nro_fact = str_pad($nro_factura, 10, "0", STR_PAD_LEFT);

 $dia= substr($fecha,8,2);
$mes= substr($fecha,5,2);
$anio= substr($fecha,0,4);

$fecha= $dia."/".$mes."/".$anio;
 

 $nro_receta=$result->fields["nro_receta"];
 $documento=$result->fields["documento"];
 $tipo_doc=$result->fields["tipo_doc"];
 $plan_completo=$result->fields["plan_completo"];
 $operador=$result->fields["operador"];
 $denominacion=$result->fields["denominacion"];
 $fecha=$result->fields["fecha"];
 $forma_pago=$result->fields["forma_pago"];
 $porc_dto=$result->fields["porc_dto"];
 $nombre_operador=$result->fields["nombre_operador"];
 $neto=$result->fields["neto"];
  $tipo_factura=$result->fields["tipo_factura"];
    $observaciones=$result->fields["observaciones"];
 $cod_movimiento=$result->fields["cod_movimiento"];

 

$sql = "SELECT * FROM `afiliaciones` where documento = $documento and tipo_doc = '$tipo_doc' order by documento";
$result9 = $db->Execute($sql);
$nro_os=$result9->fields["nro_os"];
$nro_afiliado=$result9->fields["nro_afiliado"];


$sql = "SELECT * FROM `obrasocial` where nro_os = $nro_os";
$result9 = $db->Execute($sql);

$nombre_os=strtoupper($result9->fields["nombre_os"]);
$sigla=strtoupper($result9->fields["sigla"]);

if ($nro_os == 1){
$nombre_os="";
}


$sql7="select * from pacientes where documento = $documento and tipo_doc = '$tipo_doc'";
$result7 = $db->Execute($sql7);

$estado=strtoupper($result7->fields["estado"]);
$fecha_estado=strtoupper($result7->fields["fecha_estado"]);  // letras
$calle=strtoupper($result7->fields["calle"]); // numero
$puerta=strtoupper($result7->fields["puerta"]); // numero
$localidad=strtoupper($result7->fields["localidad"]); // numero
$departamento=strtoupper($result7->fields["departamento"]); // numero
$direccion = $calle." ".$puerta." ".$localidad." ".$departamento;
$apellido=strtoupper($result7->fields["apellido"]); // numero
$nombre=strtoupper($result7->fields["nombre"]); // numero
$nombre_completo = $documento." - ".$apellido." ".$nombre;

$sql="select * from paciente_diagnostico where documento = '$documento' and tipo_doc = '$tipo_doc' order by nro_ficha desc";
$result9 = $db->Execute($sql);
$cod_diagnostico=strtoupper($result9->fields["cod_diagnostico"]); 
$nro_ficha=strtoupper($result9->fields["nro_ficha"]); 

$sql="select * from diagnostico where nro_diagnostico = '$cod_diagnostico'";
$result9 = $db->Execute($sql);
$nombre_diagnostico=strtoupper($result9->fields["nombre_diagnostico"]); 

if ($cod_movimiento == 6) {
$nombre_completo = "ANULADA";
}

 ?>
  <tr bgcolor="#FFBC79">
    <td width="8%"  bgcolor="#CCCCCC" scope="col"><div align="center"><span class="Estilo28 Estilo13 Estilo7"><?php echo $nro_factura;?></span></div></td>

    <td width="36%"  bgcolor="#CCCCCC" scope="col"><div align="center" class="Estilo26 Estilo13 Estilo7"><?php echo $fecha;?></div></td>
    <td width="23%" bgcolor="#CCCCCC" scope="col"><div align="center" class="Estilo28 Estilo13 Estilo7"><?php echo $nombre_completo;?></div></td>
    <td width="11%" bgcolor="#CCCCCC" scope="col"><div align="center" class="Estilo28 Estilo13 Estilo7"><?php echo $a;?></div></td>
    <td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $a;?></div></td>
<td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $a;?></div></td>

<td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $a;?></div></td>
<td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $a;?></div></td>
<td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $a;?></div></td>
<td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $neto;?></div></td>

 </tr>

<?php


 $sql3 = "SELECT * FROM `tr_ventas_detalle`  WHERE  nro_factura = $nro_factura  group by cod_mercaderia order by  cod_mercaderia";
$result3 = $db->Execute($sql3);

if (!$result3) die("fallo".$db->ErrorMsg());

 while (!$result3->EOF) {
$renglon = $renglon + 1;


 $cod_mer = $cod_merca;


  $cod_mercaderia=strtoupper($result3->fields["cod_mercaderia"]);
  $tipo_fact=strtoupper($result3->fields["tipo_fact"]);

$cod_merca=strtoupper($result3->fields["cod_mercaderia"]);
$precio_unitario=strtoupper($result3->fields["precio_unitario"]);



$sql5 = "SELECT sum(cantidad) as cantidad,  sum(total) as total FROM `tr_ventas_detalle`  WHERE  cod_mercaderia = '$cod_mercaderia' and nro_factura = $nro_factura";
$result5 = $db->Execute($sql5);
$cantidad=strtoupper($result5->fields["cantidad"]);

$total=strtoupper($result5->fields["total"]);

  
$proveedor=strtoupper($result3->fields["proveedor"]);
$presentacion=strtoupper($result3->fields["presentacion"]);
$descripcion=strtoupper($result3->fields["descripcion"]);
$cod_detalle=strtoupper($result3->fields["cod_detalle"]);
$gtin = $result3->fields["gtin"];
$resultado= $result3->fields["resultado"];
$transaccion= $result3->fields["transaccion"];
$lote1=strtoupper($result3->fields["lote"]);
$mes_lote=strtoupper($result3->fields["mes_lote"]);
$anio_lote=strtoupper($result3->fields["anio_lote"]);
$vto_lote = $mes_lote."/".$anio_lote;
$gtin=strtoupper($result3->fields["gtin"]);
$grupo=strtoupper($result3->fields["grupo"]); 

$sql = "SELECT * FROM `monodrogas`  WHERE  `cod_barra` = '$cod_mercaderia' or troquel = $cod_mercaderia";
$result9 = $db->Execute($sql);
$cod_mercaderia=strtoupper($result9->fields["troquel"]);
$presentacion=strtoupper($result9->fields["presentacion"]);
$nombre_comercial=strtoupper($result9->fields["nombre_comercial"]);
$cod_droga=strtoupper($result9->fields["cod_droga"]);
$laboratorio=strtoupper($result9->fields["laboratorio"]);
$grupo=strtoupper($result9->fields["grupo"]);



	if ($proveedor == 110){

		switch ($grupo){
			case "1":{$ne_grupo1 = $total;$total_grupo1 = $total_grupo1 + $ne_grupo1;break;}
			case "2":{$ne_grupo2 = $total;$total_grupo2 = $total_grupo2 + $ne_grupo2;break;}
			case "3":{$ne_grupo3 = $total;$total_grupo3 = $total_grupo3 + $ne_grupo3;break;}
					}
$prov_papo1 = "0";
$prov_papo2 = "0";
$prov_mono = "0";

	}else{ // cambia no ace
		switch ($grupo){
			case "1":{$prov_papo1 = $total;$total_prov_papo1 = $total_prov_papo1 + $prov_papo1;$total_prov_papo_grupo1 = $total_prov_papo_grupo1 + $prov_papo;break;}
			case "2":{$prov_papo2 = $total;$total_prov_papo2 = $total_prov_papo2 + $prov_papo2;$total_prov_papo_grupo2 = $total_prov_papo_grupo1 + $prov_papo;break;}
			case "3":{$prov_mono = $total;$total_prov_mono = $total_prov_mono + $prov_mono;break;}
					}

$ne_grupo1 = "0";
$ne_grupo2 = "0";
$ne_grupo3 = "0";

				}
	


 


 


if (is_numeric ($laboratorio)) { 
$sql = "SELECT * FROM laboratorios  WHERE  cod_laboratorio = '$laboratorio' ";
$result9 = $db->Execute($sql);
$laboratorio=strtoupper($result9->fields["laboratorio"]);
} 


$sql = "SELECT * FROM `drogas`  WHERE  cod_droga = '$cod_droga' ";
$result9 = $db->Execute($sql);
$droga=strtoupper($result9->fields["droga"]);

$nombre_remedio = $droga."  ".$presentacion;

$cont = $cont + 1;

$precio_unitario = str_pad($precio_unitario, 12, " ", STR_PAD_LEFT); 

//$pdf->SetX(60);



?>
  <tr bgcolor="#FFBC79">

<td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $cantidad;?></div></td>
<td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $droga;?></div></td>
<td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $presentacion;?></div></td>

<td width="8%"  bgcolor="#CCCCCC" scope="col"><div align="center"><span class="Estilo28 Estilo13 Estilo7"><?php echo $prov_papo1;?></span></div></td>

    <td width="36%"  bgcolor="#CCCCCC" scope="col"><div align="center" class="Estilo26 Estilo13 Estilo7"><?php echo $prov_papo2;?></div></td>
    <td width="23%" bgcolor="#CCCCCC" scope="col"><div align="center" class="Estilo28 Estilo13 Estilo7"><?php echo $prov_mono;?></div></td>
    <td width="11%" bgcolor="#CCCCCC" scope="col"><div align="center" class="Estilo28 Estilo13 Estilo7"><?php echo $ne_grupo1;?></div></td>
    <td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $ne_grupo2;?></div></td>
<td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $ne_grupo3;?></div></td>

<td width="3%" bgcolor="#CCCCCC" class="Estilo28" scope="col"><div align="center" class="Estilo14"><?php echo $total_renglon;?></div></td>


 </tr>

<?PHP 


$prov_papo1 = "0";
$prov_papo2 = "0";
$prov_mono = "0";
$ne_grupo1 = "0";
$ne_grupo2 = "0";
$ne_grupo3 = "0";
$total_renglon = "0";


 
 

$contame = $contame + 1;



	 $result3->MoveNext();

				}
 

 

$sumatoria = 0;
$contame = "";
$cont = 0;
$canti = "";

	

	 $result->MoveNext();

				}