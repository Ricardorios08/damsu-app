<?php 
global $buscador_rapido;
$buscador_rapido=$_POST["buscador_rapido"];
$hoy = date("d/m/y");
include ("../../conexiones/config_usu.php");

$B = 1;
$palabra=$_POST["busca"];

$sql="select * from laboratorios where cod_laboratorio like '%$palabra%'  or laboratorio  order by laboratorio asc ";

	$result = $db->Execute($sql);
?>
<table width="103%" height="58" border="0">
  <tr bordercolor="#FFFFCC" bgcolor="#E6E6E6">
    <td colspan="11"><div align="center"><font color="#000000" face="Arial, Helvetica, sans-serif">LISTADO DE LABORATORIOS . Emitido el <?php echo $hoy;?> </font></div></td>
  </tr>
  <tr bordercolor="#FFFFCC" bgcolor="#000099">
    <?php 

switch ($buscador_rapido)
{
	case "1"://mostrar sin modificar
	{ 
		?>
    <td width="5%"><div align="center"><font color="#FFFFFF" size="1" face="Arial, Helvetica, sans-serif"><strong>COD LABORATORIO</strong></font></div></td>
    <td width="11%"><div align="center"><font color="#FFFFFF" size="1" face="Arial, Helvetica, sans-serif"><strong>DENOMINACION LABORATORIO</strong></font></div></td>
	<?php 



	break;
}


	case "2": //mostrar con modificar
	{
		?>
    <td width="5%"><div align="center"><font color="#FFFFFF" size="1" face="Arial, Helvetica, sans-serif"><strong>COD LABORATORIO</strong></font></div></td>
    <td width="11%"><div align="center"><font color="#FFFFFF" size="1" face="Arial, Helvetica, sans-serif"><strong>DENOMINACION LABORATORIO</strong></font></div></td>
	
    <td width="12%"><div align="center"><font color="#FFFFFF" size="1" face="Arial, Helvetica, sans-serif"><strong>MODIFICAR</strong></font></div></td>
	<td width="12%"><div align="center"><font color="#FFFFFF" size="1" face="Arial, Helvetica, sans-serif"><strong>BORRAR</strong></font></div></td>
    

  </tr>
  <?php 


	break;
}	






}
 
  if (!$result) die("fallo".$db->ErrorMsg());
  while (!$result->EOF) {

	
$cod_laboratorio=strtoupper($result->fields["cod_laboratorio"]);
$laboratorio=strtoupper($result->fields["laboratorio"]);




	if ($B == 1) {

?>
  <tr bordercolor="#FFFFFF" bgcolor="#FFFFFF">
    <?php 
$B = 0;
				}
	ELSE	{
	$B=1;
		 	
?>
  <tr bordercolor="#FFFFCC" bgcolor="#FFFFCC">
    <?php 

			}





switch ($buscador_rapido)
{
	case "2": //mostrar sin modificar
	{
		?>
    <td bgcolor="#E8DCFC"><div align="center"><font size="2"><?php print("$cod_laboratorio");?></font></div></td>
    <td bgcolor="#E8DCFC"><div align="center"><font size="2"><?php print("$laboratorio");?></font></div></td>
    
   <td bordercolor="#E8DCFC" bgcolor="#E8DCFC"><div align="center"><font size="1" face="Arial, Helvetica, sans-serif"><a href="modificar.php?id=<?php print("$cuenta");?>"><IMG SRC="../../imagenes/office/027.ico" alt="Modificar" border = "0"></a></font></div></td>
    <td bordercolor="#E8DCFC" bgcolor="#E8DCFC"><div align="center"><font size="1" face="Arial, Helvetica, sans-serif"> <a href="borra.php?id=<?php print("$cuenta");?>"><IMG SRC="../../imagenes/office/1047.ico" alt="Eliminar" border = "0"></a></font></div></td>

  </tr>
  <?php 



break;
}


case "1":
	  {
	?>
<td bgcolor="#E8DCFC"><div align="center"><font size="2"><?php print("$cod_laboratorio");?></font></div></td>
    <td bgcolor="#E8DCFC"><div align="center"><font size="2"><?php print("$laboratorio");?></font></div></td>
  <?php 

	break;
	  }
	  }

$result->MoveNext();
	}

?>
</table>
