<?php 
include ("../../../conexiones/config_pro.php");

//tabla clientes
$cuenta=$_POST["cuenta"];
$estado=$_POST["estado"];
$denominacion=$_POST["denominacion"];
$domicilio=$_POST["domicilio"];
$puerta=$_POST["puerta"];
$referencia=$_POST["referencia"];
$cod_postal =$_POST["cod_postal"];


$localida=$_POST["localidad"];
	for ($i=0;$i<count($localida);$i++)    
	{     
	$localidad = $localida[$i];    
	}

$caracteristica_1=$_POST["caracteristica_1"];
$telefono_1=$_POST["telefono_1"];
$caracteristica_2=$_POST["caracteristica_2"];
$telefono_2=$_POST["telefono_2"];
$caracteristica_3=$_POST["caracteristica_3"];
$telefono_3=$_POST["telefono_3"];
$email=$_POST["email"];
$cuit=$_POST["cuit"];



$sql = "INSERT INTO `clientes` ( `cuenta` , `estado` , `denominacion` , `domicilio` , `puerta` , `referencia` , `cod_postal` , `localidad` , `caracteristica_1` , `telefono_1` , `caracteristica_2` , `telefono_2` , `caracteristica_3` , `telefono_3` , `email`, `cuit`) VALUES ('$cuenta' , '$estado' , '$denominacion' , '$domicilio' , '$puerta' , '$referencia' , '$cod_postal' , '$localidad' , '$caracteristica_1' , '$telefono_1' , '$caracteristica_2' , '$telefono_2' , '$caracteristica_3' , '$telefono_3' , '$email', '$cuit')";
mysql_query($sql);






//tabla condiciones_clientes



$ivas=$_POST["iva"];
for ($i=0;$i<count($ivas);$i++)    
{     
$iva = $ivas[$i];    
}

$ingresos_bruto=$_POST["ingresos_brutos"];
for ($i=0;$i<count($ingresos_bruto);$i++)    
{     
$ingresos_brutos= $ingresos_bruto[$i];    
}

$condicione=$_POST["condiciones"];
for ($i=0;$i<count($condicione);$i++)    
{     
$condiciones= $condicione[$i];    
}
$credito=$_POST["credito"];

$flet=$_POST["flete"];
for ($i=0;$i<count($flet);$i++)    
{     
$flete= $flet[$i];    
}


$plan=$_POST["plan"];

$observaciones=$_POST["observaciones"];


if ($denominacion == ""){
$leyenda = "NO INGRESO DENOMINACION O RAZON SOCIAL";
include ("../../../alertas/campo_vacio.php");
	exit;
}

if ($cuit == ""){
$leyenda = "NO INGRESO NUMERO DE CUIT";
include ("../../../alertas/campo_vacio.php");
	exit;
}


include ("../../../conexiones/config_pro.php");
 $sql = "INSERT INTO `condiciones_clientes` ( `cuenta` , `iva` , `ingresos_brutos` , `condiciones` , `plan` , `credito` , `flete` , `observaciones` ) VALUES ( '$cuenta' , '$iva' , '$ingresos_brutos' , '$condiciones' , '$plan' ,'$credito' , '$flete' , '$observaciones')";

mysql_query($sql);

$leyenda = "LOS DATOS SE HAN GUARDADO CORRECTAMENTE ";
include ("../../../alertas/campo_vacio.php");
include ("../../proveeduria/clientes/entrada_dato.php");

?>

