<?php global $band;
$id = $_REQUEST["id"];

include("../../../conexiones/config_pro.php");
include ("../../../conexiones/usuario_compra.php");


$sql = "DELETE from compras1_encab_temp where operador = $id";
$result = $db->Execute($sql);
$sql = "DELETE from compras1_deta_temp where operador = $id";
$result = $db->Execute($sql);


?>
<script>
function on_load()
{
document.getElementById("cod_mercaderia").focus();
}

function enter()
{
document.getElementById("cod_mercaderia").focus();
}


function verif_caracter(obj,evt)

{

	evt = (evt) ? evt : event;
	var charCode = (evt.charCode) ? evt.charCode : ((evt.which) ? evt.which : evt.keyCode);
	if (charCode == 13) 

	
	{
		switch(obj.id)
		{
				case "cod_mercaderia":
				document.getElementById("lote").focus();
				break;
				case "lote":
				document.getElementById("mes_lote").focus();
				break;
				case "mes_lote":
				document.getElementById("anio_lote").focus();
				break;

								case "anio_lote":
				document.getElementById("precio_unitario").focus();
				break;

					
				case "precio_unitario":
				document.getElementById("gtin").focus();
				break;

				case "gtin":
				document.getElementById("SI").focus();
				break;

				
				
		}
		return false;
	}
	return true;
}


function abrirVentan() {
	var cod_detalle = <?php echo $cod_detalle;?> 
    open("buscador_rapido_mercaderia.php","miVentana", "width=300,height=600,toolbar=no,directories=no,menubar=no,status=no, scrollbars=01, top = 35");
}

</script>
<?php if ($band != "SI"){


$nro_proveedor = $_REQUEST['nro_proveedor'];

include ("../../../conexiones/config_usu.php");
$sql="select * from proveedores where cod_proveedor = $nro_proveedor";
$result = $db->Execute($sql);
$denominacion=strtoupper($result->fields["denominacion"]);

if ($denominacion == ""){
	$leyenda = "NO EXISTE PROVEEDOR CON ESE NUMERO";
	INCLUDE ("../../../alertas/campo_vacio.php");
	exit;
}



$dia= $_REQUEST['dia'];
$mes= $_REQUEST['mes'];
$anio= $_REQUEST['anio'];
$fecha = $anio."-".$mes."-".$dia;
$fecha1 =$dia."-".$mes."-".$anio;

$operador= $_REQUEST['id'];


$cod_movimient=$_REQUEST["cod_movimiento"];
	for ($i=0;$i<count($cod_movimient);$i++)    
	{     
	$cod_movimiento = $cod_movimient[$i];    
	}



$nro_factura= $_REQUEST['nro_factura'];
$porcentaje_boni= $_REQUEST['porcentaje_boni'];
$porcentaje_dto= $_REQUEST['porcentaje_dto'];



if ($nro_proveedor == ""){
	$leyenda = "NO PUEDE DEJAR EL CAMPO NRO DE PROVEEDOR EN BLANCO";
	INCLUDE ("../../../alertas/campo_vacio.php");
	exit;
}

if ($nro_factura == ""){
	$leyenda = "NO PUEDE DEJAR EL CAMPO NRO DE COMPROBANTE EN BLANCO";
	INCLUDE ("../../../alertas/campo_vacio.php");
	exit;
}

//include ("../comprobar_fechas.php");

$periodo = date("m"); 
$anio1 = date("y"); 

$sql = "INSERT INTO `tr_compras1_encab_temp` ( `nro_factura` , `cod_operacion` , `nro_proveedor` , `denominacion` , `fecha` , `descuento` , `bonificacion` , `periodo` , `anio` , `operador`  , `cod_movimiento` ) VALUES ( '$nro_factura' , '$cod_operacion' , '$nro_proveedor' , '$denominacion', '$fecha' , '$porcentaje_dto' , '$porcentaje_boni' , '$periodo' , '$anio1' , '$id' , '$cod_movimiento' )";
mysql_query($sql);

}




?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Documento sin t&iacute;tulo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body onload = "on_load ()">
<FORM name="form" ACTION="pagina2.php" METHOD = "POST">


<table width="800" border="0" cellspacing="0">
  <tr bgcolor="#000099">
    <td height="27" colspan="4" bgcolor="#CCCCCC"><div align="center"><font color="#000000" face="Trebuchet MS">INGRESO DE MEDICAMENTOS </font>POR ANMAT </div></td>
    <td height="27" colspan="2" bgcolor="#CCCCCC"><div align="right"><font color="#000000" face="Trebuchet MS"><font size="2">Operador:</font> <?php echo $nombre_usuario;?></font></div></td>
  </tr>
  <tr bgcolor="#E1F2EF">
    <td colspan="6" bgcolor="#E6E6E6"><div align="left"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"> Proveedor: </font>        <font color="#FF0000" size="2" face="Arial, Helvetica, sans-serif"> <?php echo $denominacion;?> (<?php echo $nro_proveedor;?>) &nbsp;&nbsp;&nbsp;&nbsp;</font><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><font size="2" face="Arial, Helvetica, sans-serif">Fecha/Compra: </font><font color="#FF0000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $fecha1;?> &nbsp;&nbsp;&nbsp;&nbsp;</font><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><font size="2" face="Arial, Helvetica, sans-serif">N&ordm; Comprobante:</font> <font color="#FF0000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $nro_factura;?> &nbsp;&nbsp;&nbsp;&nbsp;</font><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><font size="2" face="Arial, Helvetica, sans-serif">Descuento %:</font> <font color="#FF0000" size="2" face="Arial, Helvetica, sans-serif"><?php echo $porcentaje_dto;?></font></div></td>
  </tr>
  <tr bgcolor="#E8DCFC">
    <td colspan="6" bgcolor="#E6E6E6">      
      <div align="center"></div></td>
  </tr>
  <tr bgcolor="#E8DCFC">
    <td width="17%" bgcolor="#E6E6E6"><div align="center"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">COD BARRA</font></div></td>
    <td width="21%" bgcolor="#E6E6E6"><div align="center"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Lote</font></div></td>
    <td width="18%" bgcolor="#E6E6E6"><div align="center"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Mes - A&ntilde;o </font></div></td>
    <td width="10%" bgcolor="#E6E6E6"><div align="center"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Pr. Unit</font></div></td>
    <td width="21%" bgcolor="#E6E6E6"><div align="center"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Gtin</font></div></td>
    <td width="13%" bgcolor="#E6E6E6"><div align="center"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif">Agregar</font></div></td>
  </tr>
  <tr bgcolor="#E8DCFC">
    <td bgcolor="#E6E6E6"><div align="center"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#006600">
        <input type = "text" name = "cod_mercaderia" id="cod_mercaderia" size = "14" onKeyPress="return verif_caracter(this,event)">
    </font></strong></font></div></td>
    <td bgcolor="#E6E6E6"><font color="#000000" size="2">
      <input type = "text" name = "lote" id="lote" size = "20" onKeyPress="return verif_caracter(this,event)">
    </font></td>
    <td bgcolor="#E6E6E6"><div align="center"><font color="#000000" size="2">
        <input type = "text" name = "mes_lote" id="mes_lote" size = "2" onKeyPress="return verif_caracter(this,event)" >
      /</font><font color="#000000" size="2"> 20
        <input name = "anio_lote" type = "text" id="anio_lote" onKeyPress="return verif_caracter(this,event)" size = "2" maxlength="2" >
      </font></div></td>
    <td bgcolor="#E6E6E6"><div align="center"><font color="#000000" size="2">
        <input type = "text" name = "precio_unitario" id="precio_unitario" size = "5" value = "<?php echo number_format($precio_actualizado,2);?>"onKeyPress="return verif_caracter(this,event)" >
    </font></div></td>
    <td bgcolor="#E6E6E6"><div align="center">
        <input type = "text" name = "gtin" id="gtin"  tabindex = "2" size = "25">
    </div></td>
    <td bgcolor="#E6E6E6"><div align="center">
        <input name="Alta" type="submit" value="SI" id ="SI" size = "10" >
        <font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#006600">
        <!-- <input name="Alta2" type="submit" value="OK" id ="Alta" size = "10" > -->
        <input name="Alta" type="submit" value= "BUSCAR" id = "Alta6">
    </font></strong></font></div></td>
  </tr>
  <tr bgcolor="#E8DCFC">
    <td colspan="6" bgcolor="#E6E6E6"><font color="#000000" size="2" face="Arial, Helvetica, sans-serif"><strong><font color="#006600">
      <input name="id" type="hidden" value ="<?php echo $id;?>">
   
      <input name="bande" type="hidden" value ="SI">
    </font></strong></font></td>
  </tr>
</table>


