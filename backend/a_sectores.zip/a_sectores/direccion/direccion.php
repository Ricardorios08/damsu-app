<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Documento sin t&iacute;tulo</title>

<style type="text/css">
<!--
.Estilo3 {
	font-family: "Trebuchet MS";
	color: #FFFFFF;
}
-->
</style>
<link href="../../menus.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.Estilo13 {font-size: 12px; font-family: Arial, Helvetica, sans-serif; }
.Estilo6 {color: #0000FF}
.Estilo5 {font-size: 12px}
.Estilo4 {font-size: xx-small}
.Estilo7 {font-family: Arial, Helvetica, sans-serif}
.Estilo21 {
	color: #FFFFFF;
	font-family: Arial, Helvetica, sans-serif;
}
.Estilo22 {font-family: "Trebuchet MS"}
-->
</style>
</head>

<body>
<table width="154"  border="0">
  <tr bgcolor="#990033"> </tr>
  <tr>
    <td bgcolor="#666666"><div align="center" class="Estilo3">DIRECCION</div></td>
  </tr>
</table>
<div id="menuv">
		<ul>
			<ul>
			 			  
<li><a href="../../a_sectores/direccion/registrar_prestaciones.php" title="Modifica las practicas en orden secuencial" target = "central1" class="Estilo54">1. REG. PRESTACIONES</a></li>

</ul>
		</ul>
</div>
  
<form action="busquedas.php" method="post" target = "central1">
 <table width="154" border="0">
    <tr>
      <td width="176" height="25" bgcolor="#666666"><div align="center" class="Estilo19 Estilo21 Estilo22"><span class="Estilo3">Buscar</span></div></td>
    </tr>
    
    <tr>
      <td><select name="busqueda[]" id="select2"><optgroup label="Pacientes">
        <div align="center">
        <option value="obra_social" selected="selected"><span class="Estilo22">OBRA SOCIAL</span></option>
        <option value="fuentes"><span class="Estilo22">FUENTES</span></option>
        <option value="diagnosticos"><span class="Estilo22">DIAGNOSTICOS</span></option>
        <option value="prestaciones"><span class="Estilo22">PRESTACIONES</span></option>
        <option value="protocolos"><span class="Estilo22">PROTOCOLOS</span></option>

		<option value="monodrogas"><span class="Estilo22">MONODROGAS</span></option>
		<option value="drogas"><span class="Estilo22">DROGAS</span></option>
		<option value="laboratorios"><span class="Estilo22">LABORATORIOS</span></option>
		<option value="proveedores"><span class="Estilo22">PROVEEDORES</span></option>




        </div>
        </optgroup>

        </select>
          </div>      </td>
    </tr>
    
    <tr>
      <td><span class="Estilo22">
      <input type = "text" name = "busca" size = "12" />
      <input type = "submit" name = "ok" value = "OK" />
      <input type="hidden" name="buscador_rapido" value="2" />
      </span></td>
    </tr>
  </table>
  </form> 
  
</body>
</html>
